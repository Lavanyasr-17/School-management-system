#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<cstdlib>
#include<windows.h>
using namespace std;
int choice;
int main();
void about();
void admin(int);
class teacher
{
 public:	
	 string fst_name;//first name of teacher
	 string lst_name;//last name of teacher
	 string tid;
	 string qualification;//Qualification of teacher
	 string exp;//Experiance of the person
	 string pay;//Pay of the Teacher
	 string subj;//subject whos he/she teach
	 string lec;//Lecture per Week
	 string addrs;//Adders of teacher home
	 string cel_no;//Phone number 
	 string blod_grp;//Bool Group 
	 string serves;//Number of serves in School
	 string buffer1;
	 bool t=1;
	 void read();
	 void pack();
	 void unpack();
	 void ori();
	 void write();
	 int search(string);
	 int delete_(string);
	 void modify(string);
	 void salary(string);
};
class student
{ public:
	 string fname;//for student first name
	 string lname;//for student last name
	 string Rollno;//for Registration No number
	 string classes;//for class info
	 string dob;
	 string bt;
	 bool te=1;
	 string percentage;
	 string buffer2;
	 void reads();
	 void packs();
	 void unpacks();
	 void oris();
	 void writes();
	 int searchs(string);
	 int deletes_(string);
	 void modifys(string);
	 
	 void grade(string);
};
void teacher::read()
{
	cout<<"\n\t\t\t\tenter first name:";
	cin>>fst_name;
	cout<<"\n\t\t\t\tenter last name:";
	cin>>lst_name;
	cout<<"\n\t\t\t\tenter teacher id:";
	cin>>tid;
	cout<<"\n\t\t\t\tenter qualification:";
	cin>>qualification;
	cout<<"\n\t\t\t\tenter experience:";
	cin>>exp;
	cout<<"\n\t\t\t\tSubject  teaching: ";
	cin>>subj;
	cout<<"\n\t\t\t\tEnter Lecture(per Week): ";
	cin>>lec;
	cout<<"\n\t\t\t\tpay(per class): ";
	cin>>pay;
	cout<<"\n\t\t\t\tEnter Phone Number: ";
  	cin>>cel_no;
  	cout<<"\n\t\t\t\tEnter Blood Group: ";
  	cin>>blod_grp;

}
void teacher::pack()
{
	string t;
	buffer1.erase();
	buffer1+=fst_name+"|"+lst_name+"|"+tid+"|"+qualification+"|"+exp+"|"+subj+"|"+lec+"|"+pay+"|"+cel_no+"|"+blod_grp+"$";
	for(;buffer1.size()<50;)
	buffer1+='$';
	buffer1+='\n';
}
void teacher::write()
{
	fstream file;
	file.open("teacher.txt",ios::out|ios::app);
	file<<buffer1;
	file.close();
}
void teacher::ori()
{
	fstream file;
	file.open("oriteacher.txt",ios::out|ios::app);
	file<<buffer1;
	file.close();
}
void teacher:: unpack()
{
	int ch=1,i=0;
	fst_name.erase();
	while(buffer1[i]!='|')
	fst_name+=buffer1[i++];
	lst_name.erase();
	i++;
	while(buffer1[i]!='|')
	lst_name+=buffer1[i++];
	tid.erase();
	i++;
	while(buffer1[i]!='|')
	tid+=buffer1[i++];
	qualification.erase();
	i++;
	while(buffer1[i]!='|')
	qualification+=buffer1[i++];
	exp.erase();
	i++;
	while(buffer1[i]!='|')
	exp+=buffer1[i++];
	subj.erase();
	i++;
	while(buffer1[i]!='|')
	subj+=buffer1[i++];
	lec.erase();
	i++;
	while(buffer1[i]!='|')
	lec+=buffer1[i++];
	pay.erase();
	i++;
	while(buffer1[i]!='|')
	pay+=buffer1[i++];
	cel_no.erase();
	i++;
	while(buffer1[i]!='|')
	cel_no+=buffer1[i++];
	blod_grp.erase();
	i++;
	while(buffer1[i]!='$')
	blod_grp+=buffer1[i++];
}
int teacher::search(string key)
{
	ifstream file;
	int flag=0,pos=0;
	file.open("teacher.txt",ios::in);
	while(!file.eof())
	{
		buffer1.erase();
		pos=file.tellg();
		getline(file,buffer1);
		unpack();
		if(key==fst_name)
		{
			cout<<"\n\t\t\t\t\tfound the key .the record is...\n"<<"\n\t\t\t\t"<<buffer1;
			flag=1;
			return pos;
		}
	}
	file.close();
	if(flag==0)
	{
		cout<<"\n\t\t\t\tnot found..\n";
		return -1;
	}
}
int teacher::delete_(string key)
{
	fstream file3;
	int pos, flag=0;
	pos=search(key);
	if(pos>=0)
	{
		file3.open("teacher.txt");
		file3.seekp(pos-1,ios::beg);
		file3.put('*');
		flag=1;
		t=0;
		file3.close();
	}
	if(flag==1) return 1;
	else
	return 0;
}	
void teacher::modify(string key)
{
	int c;
	if(delete_(key))
	{
		cout<<"\n\t\t\t\twhat to modify\n\t\t\t\t1:first name \n\t\t\t\t2:last name \n\t\t\t\t3:teacher id\n\t\t\t\t 4:qualification\n\t\t\t\t 5:experience \n\t\t\t\t6:Subject teaching\n\t\t\t\t7:Lecture(per Week)\n\t\t\t\t8:pay(per week)\n\t\t\t\t9:Phone Number\n\t\t\t\t10:Blood group\n";
		cin>>c;
		switch(c)
		{
			case 1:cout<<"\n\t\t\t\tfirst name:";
			cin>>fst_name;
			break;
			case 2:cout<<"\n\t\t\t\tlast name:";
			cin>>lst_name;
			break;
			case 3:cout<<"\n\t\t\t\tteacher id:";
			cin>>tid;
			break;
			case 4:cout<<"\n\t\t\t\tqualification:";
			cin>>qualification;
			break;
			case 5:cout<<"\n\t\t\t\texperience:";
			cin>>exp;
			break;
			case 6:cout<<"\n\t\t\t\tSubject teaching:";
			cin>>subj;
			break;
			case 7:cout<<"\n\t\t\t\tLecture(per Week):";
			cin>>lec;
			break;
			case 8:cout<<"\n\t\t\t\tpay(per week):";
			cin>>pay;
			break;
			case 9:cout<<"\n\t\t\t\tPhone Number:";
			cin>>cel_no;
			break;
			case 10:cout<<"\n\t\t\t\tBlood group:";
			cin>>blod_grp;
			break;
			default:cout<<"\n\t\t\t\twrong choice";
		}
		//buffer1.erase();
		pack();
		write();
	}
}
void teacher::salary(string key)
{
	int p=0,c=0,l=0;
	c=search(key);
	if (c!=-1)
	c=1;
	if (t==1&&c==1)
	{
		stringstream g(pay);
		g>>p;
		stringstream ga(lec);
		ga>>l;
		cout<<"\n\t\t\t\tpay per class:"<<p;
		cout<<"\n\t\t\t\tlecture per week is:"<<l;
		cout<<"\n\t\t\t\tsalary per month is :$"<<31*p*l;
	}
	else
	cout<<"\n\t\t\t\trecord not found";
	pack();
}
void student::reads()
{
	cout<<"\n\t\t\t\tenter first name:";
	cin>>fname;
	cout<<"\n\t\t\t\tenter last name:";
	cin>>lname;
	cout<<"\n\t\t\t\tenter roll no:";
	cin>>Rollno;
	cout<<"\n\t\t\t\tenter class studying:";
	cin>>classes;
	cout<<"\n\t\t\t\tEnter date of birth: ";
	cin>>dob;
	cout<<"\n\t\t\t\tEnter blood type: ";
	cin>>bt;
	cout<<"\n\t\t\t\tEnter Percentage obtained: ";
  	cin>>percentage;
  	
}
void student::packs()
{
	string t;
	buffer2.erase();
	buffer2+=fname+"|"+lname+"|"+Rollno+"|"+classes+"|"+dob+"|"+bt+"|"+percentage+"$";
	for(;buffer2.size()<50;)
	buffer2+='$';
	buffer2+='\n';
}
void student::writes()
{
	fstream file;
	file.open("stud.txt",ios::out|ios::app);
	file<<buffer2;
	file.close();
}
void student::oris()
{
	fstream file;
	file.open("oristud.txt",ios::out|ios::app);
	file<<buffer2;
	file.close();
}
void student::unpacks()
{
	int ch=1,i=0;
	fname.erase();
	while(buffer2[i]!='|')
	fname+=buffer2[i++];
	lname.erase();
	i++;
	while(buffer2[i]!='|')
	lname+=buffer2[i++];
	Rollno.erase();
	i++;
	while(buffer2[i]!='|')
	Rollno+=buffer2[i++];
	classes.erase();
	i++;
	while(buffer2[i]!='|')
	classes+=buffer2[i++];
	dob.erase();
	i++;
	while(buffer2[i]!='|')
	dob+=buffer2[i++];
	bt.erase();
	i++;
	while(buffer2[i]!='|')
	bt+=buffer2[i++];
	percentage.erase();
	i++;
	while(buffer2[i]!='$')
	percentage+=buffer2[i++];
}
int student::searchs(string key)
{
	ifstream file;
	int flag=0,pos=0;
	file.open("stud.txt",ios::in);
	while(!file.eof())
	{
		buffer2.erase();
		pos=file.tellg();
		getline(file,buffer2);
		unpacks();
		if(key==fname)
		{
			cout<<"\n\t\t\t\t\tfound the key .the record is...\n"<<"\n\t\t\t\t"<<buffer2;
			flag=1;
			return pos;
		}
	}
	file.close();
	if(flag==0)
	{
		cout<<"\n\t\t\t\tnot found..\n";
		return -1;
	}
}
int student::deletes_(string key)
{
	fstream file3;
	int pos, flag=0;
	pos=searchs(key);
	if(pos>=0)
	{
		file3.open("stud.txt");
		file3.seekp(pos,ios::beg);
		file3.put('*');
		flag=1;
		te=0;
		file3.close();
	}
	if(flag==1) return 1;
	else
	return 0;
}	
void student::modifys(string key)
{
	int c;
	if(deletes_(key))
	{
		
		cout<<"\n\t\t\t\twhat to modify\n\t\t\t\t1:first name \n\t\t\t\t2:last name \n\t\t\t\t3:Roll no\n\t\t\t\t 4:class\n\t\t\t\t 5:date of birth \n\t\t\t\t6:Blood type\n\t\t\t\t7:percentage\n";
		cin>>c;
		switch(c)
		{
			case 1:cout<<"\n\t\t\t\tfirst name:";
			cin>>fname;
			break;
			case 2:cout<<"\n\t\t\t\tlast name:";
			cin>>lname;
			break;
			case 3:cout<<"\n\t\t\t\tRollno:";
			cin>>Rollno;
			break;
			case 4:cout<<"\n\t\t\t\tclass:";
			cin>>classes;
			break;
			case 5:cout<<"\n\t\t\t\tdate of birth:";
			cin>>dob;
			break;
			case 6:cout<<"\n\t\t\t\tBlood type:";
			cin>>bt;
			break;
			case 7:cout<<"\n\t\t\t\tPercentage:";
			cin>>percentage;
			break;
			default:cout<<"\n\t\t\t\twrong choice\n";
		}
		//cout<<"\n\t\t\t\t"<<buffer2;
		packs();
		writes();
	}
}	
void student::grade(string key)
{	
	int p=0;
	int c=0;
	c=searchs(key);
	if (c!=-1)
	c=1;
	if (te==1&&c==1)
	{
		cout<<"\n\t\t\t\t name of the student:"<<fname;
		cout<<"\n\t\t\t\t percentage obtained:"<<percentage;
		stringstream g(percentage);
		g>>p;
		if(p<100&&p>=90)
		cout<<"\n\t\t\t\tA grade";
		else if(p<90&&p>=75)
		cout<<"\n\t\t\t\t B grade";
		else if(p<75&&p>=55)
		cout<<"\n\t\t\t\t C grade";
		else if(p<55&&p>=35)
		cout<<"\n\t\t\t\t D grade";
		else
		cout<<"\n\t\t\t\tFAIL";
	}
}
int verify_password()
{	
	string user_name="lavanya";
	string password="";
	string u_name;
	string u_pwd;
	char ch;
	cout<<"\n\n\t\t\t\t   Enter user name : ";
	cin>>u_name;
	cout<<"\n\n\t\t\t\t   Enter Password : ";
	ch=getch();
	while(ch!=13)
	{
		password.push_back(ch);
		cout<<'*';
		ch=_getch();
	}
	if(user_name==u_name&&password=="lavanya")
	{

		cout<<"\t\t\t\tlogin succesfull";
 		return 0;
	}
	else
	{
	cout<<"\n\t\t\t\tLOGIN FAILED";
	system("cls");	
}
}
void attendance(string key)
{	
	int a=0,i;
	stringstream g(key);
		g>>a;
		a=a*12;
		if(a>=100)
		a=a/10;
		if(a>=100)
		a=a/2;
	cout<<"\t\t\t\tattendance of "<<key<<" is";
	cout<<a<<"%";
	admin(0);
}
void open()
{
  int i=0;
  cout<<("\n");
  cout<<("\t\t\t\t    ==============================================\n");
  cout<<("\t\t\t\t    ==============================================\n");
  cout<<("\t\t\t\t    		 SCHOOL MANAGEMENT SYSTEM \n");
  cout<<("\t\t\t\t    ==============================================\n");
  cout<<("\t\t\t\t    ==============================================\n");
  cout<<("\n\n\n");
  cout<<("\t\t\t\t");
  cout<<("\tADMIN\t\tTEACHER\t\tSTUDENT");
  cout<<("\n\n\t\t\t\t\t\tEXIT\t\t  ABOUT");
  cout<<("\n\n\t\t\t\t\t\tCHOOSE [1/2/3/4/5]:-");
  cin>>choice;
  if(choice==4)
  exit(0);
  if(choice==5)
  about();
  cout<<("\n\n");
  cout<<"\n\t\t\t\t   Loading";
  while(i!=40)
  {
  	cout<<".";
  	Sleep(100);
  	i++;
  }
  cout<<("\n\t\t\t\t    Press Enter to continue......");
  getch();
}
void about()
{	
  
  system("cls");
  	system("color 5f");
  cout<<("\t\t\t\t    ==============================================\n");
  cout<<("\t\t\t\t    		 SCHOOL MANAGEMENT SYSTEM \n");
  cout<<("\t\t\t\t    ==============================================\n");
  cout<<("\t\t\t\t    |School management c++ project contains both |\n");
  cout<<("\t\t\t\t    |student and teacher record management system|\n");
  cout<<("\t\t\t\t    |It has 2 class for student and teacher each |\n");
  cout<<("\t\t\t\t    |The main screen has 3 options namely Admin, |\n");
  cout<<("\t\t\t\t    |Teacher and Student.Admin can access all the|\n");
  cout<<("\t\t\t\t    |information & check their attendance status.|\n");
  cout<<("\t\t\t\t    |Student and Teacher have some functionality.|\n");
  cout<<("\t\t\t\t    |This project mainly focuses on indexing and |\n");
  cout<<("\t\t\t\t    |and other concepts of filestructure .       |\n");
  cout<<("\t\t\t\t    ==============================================\n");
  cout<<"\t\t\t\t      press any button to continue";
  getch();
  system("cls");
  main();
}
void admin(int x)
{	student s;
	teacher t;
	fstream f;
	int c1,i;
	ifstream f1;
	string l;
	string key,b;
  	if (!x)
  		{
		  	
  			cout<<("\n\t\t\t\t    ==============================================");
	 		cout<<"\n\t\t\t\t1.search a student\n\t\t\t\t2.search a teacher\n\t\t\t\t3.attendance of a student\n\t\t\t\t4.attendance of a teacher\n\t\t\t\t5.view all the students\n\t\t\t\t6.view all the teacher\n\t\t\t\t7.exit";
		    cout<<"\n\t\t\t\tchoose[1/2/3/4/5/6/7]";
			cin>>c1;
			cout<<("\n\t\t\t\t    ==============================================");
			 switch(c1)
		   {
		    	case 1: cout<<"\n\t\t\t\tenter the first name:";
						cin>>key;
						i=s.searchs(key);
						break;
				case 2:cout<<"\n\t\t\t\tenter the first name:";
						cin>>key;
						i=t.search(key);
						break;
				case 3:cout<<"\n\t\t\t\tenter the Roll no:";
						cin>>key;
						attendance(key);
						break;
				case 4:cout<<"\n\t\t\t\tenter the tid:";
						cin>>key;
						attendance(key);
						break;
				case 5:	f1.open("oristud.txt");
						if(!f1)
						{
						cout<<"error in opening";
						f1.close();
						break;
						}
						while(getline(f1,l))
						cout<<"\n\t\t\t\t"<<l;
						f1.close();
						break;
				case 6:f1.open("oriteacher.txt");
						if(!f1)
						{
						cout<<"error in opening";
						f1.close();
						break;
						}
						while(getline(f1,l))
						cout<<"\n\t\t\t\t"<<l;
						f1.close();
						break;
				case 7:system("cls");
						main();
						exit(0);
				default:cout<<"\t\t\t\twrong choice";
			}
		}
		else
		cout<<"\n\t\t\t\twrong user name or password ";
  		
}
void teach()
{		int c2,count,i;
		string key;
		teacher t;
		cout<<("\n\t\t\t\t    ==============================================");
		cout<<"\n\t\t\t\t1.add\n\t\t\t\t2.delete\n\t\t\t\t3.modify\n\t\t\t\t4.search\n\t\t\t\t5.salary\n\t\t\t\t6.exit \n\t\t\t\t enter your choice";
		cin>>c2;
		cout<<("\n\t\t\t\t    ==============================================");
		switch(c2)
		{
			case 1: cout<<"\n\t\t\t\thow many records to insert";
					cin>>count;
					for(i=0;i<count;i++)
					{
						cout<<"\n\t\t\t\tdata";
						t.read();
						t.pack();
						t.write();
						t.ori();
					}
					break;
			case 2: cout<<"\n\t\t\t\tenter the first name...";
					cin>>key;
					i=t.delete_(key);
					if(i==1)
					cout<<"\n\t\t\t\trecord deleted";
					else
					cout<<"\n\t\t\t\trecord not deleted";
					break;
			case 3: cout<<"\n\t\t\t\tenter the first name";
					cin>>key;
					t.modify(key);
					break;
			case 4: cout<<"\n\t\t\t\tenter the first name";
					cin>>key;
					i=t.search(key);
					break;
			case 5: cout<<"\n\t\t\t\tenter the first name";
					cin>>key;
					t.salary(key);
					break;
			case 6:system("cls");
					main();
					exit(0);
			default:cout<<"\t\t\t\twrong choice....";
			}
		
		
}
void stud()
{		int c3,count,i;
		string key;
		student s;
		cout<<("\n\t\t\t\t    ==============================================");
		cout<<"\n\t\t\t\t1.add\n\t\t\t\t2.delete\n\t\t\t\t3.modify\n\t\t\t\t4.search\n\t\t\t\t5.grade\n\t\t\t\t6.exit \n\t\t\t\t enter your choice";
		cin>>c3;
		cout<<("\n\t\t\t\t    ==============================================");
		switch(c3)
		{
			case 1: cout<<"\n\t\t\t\thow many records to insert\n";
					cin>>count;
					for(i=0;i<count;i++)
					{
						cout<<"\n\t\t\t\tdata";
						s.reads();
						s.packs();
						s.writes();
						s.oris();
					}
					break;
			case 2: cout<<"\n\t\t\t\tenter the first name...";
					cin>>key;
					i=s.deletes_(key);
					if(i==1)
					cout<<"\n\t\t\t\trecord deleted";
					else
					cout<<"\n\t\t\t\trecord not deleted";
					break;
			case 3: cout<<"\n\t\t\t\tenter the first name";
					cin>>key;
					s.modifys(key);
					break;
			case 4: cout<<"\n\t\t\t\tenter the first name";
					cin>>key;
					i=s.searchs(key);
					break;
			case 5: cout<<"\n\t\t\t\tenter the first name";
					cin>>key;
					s.grade(key);
					break;
			case 6:system("cls");
					main();
					exit(0);
			default:cout<<"\t\t\t\twrong choice....";
			}

		
}
int main()
{
int count,i,process;
string key;

while(1)
{
system("color f0");	
  open();
  switch(choice)
  {
  	case 1: system("cls");
  			system("color 5f");
		  	cout<<("\t\t\t\t    ==============================================\n");
		  	cout<<("\t\t\t\t    		 ADMIN LOGIN SCREEN \n");
		  	cout<<("\t\t\t\t    ==============================================\n");	
		  	count=verify_password();
		  	system("cls");
		  	system("color 5f");
		  	cout<<("\n\t\t\t\t    ==============================================");
		  	cout<<("\n\t\t\t\t    		 ADMIN MAIN MENU \n");
  			cout<<("\t\t\t\t    ==============================================\n");	
		  	while(1)
		  	admin(count);
		  	break;
  	case 2:system("cls");
  			system("color 5f");
		  	cout<<("\t\t\t\t    ==============================================\n");
		  	cout<<("\t\t\t\t    		 TEACHER MAIN MENU \n");
		  	cout<<("\t\t\t\t    ==============================================\n");	
		 	while(1) 
		  	teach();
		  	break;
  	case 3:system("cls");
  			system("color 5f");
		  	cout<<("\t\t\t\t    ==============================================\n");
		  	cout<<("\t\t\t\t    		 STUDENT MAIN MENU \n");
		  	cout<<("\t\t\t\t    ==============================================\n");	
		 	while(1) 
		  	stud();
		  	break;
  	case 4:exit(0);
  }
}
return 0;
}
